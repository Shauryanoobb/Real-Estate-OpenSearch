--
-- PostgreSQL database dump
--

\restrict d5CrC7zvcgaibmkiFHe6TCk3gly0gb5vHfx5qJOrzTuns9NEcjkBc8jQ7bGtxFr

-- Dumped from database version 16.1
-- Dumped by pg_dump version 17.6 (Debian 17.6-0+deb13u1)

-- Started on 2025-12-08 07:18:30 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS realestate_db;
--
-- TOC entry 3422 (class 1262 OID 16384)
-- Name: realestate_db; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE realestate_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


\unrestrict d5CrC7zvcgaibmkiFHe6TCk3gly0gb5vHfx5qJOrzTuns9NEcjkBc8jQ7bGtxFr
\connect realestate_db
\restrict d5CrC7zvcgaibmkiFHe6TCk3gly0gb5vHfx5qJOrzTuns9NEcjkBc8jQ7bGtxFr

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 848 (class 1247 OID 16412)
-- Name: furnishing_statuses; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.furnishing_statuses AS ENUM (
    'FURNISHED',
    'UNFURNISHED',
    'SEMI_FURNISHED'
);


--
-- TOC entry 845 (class 1247 OID 16406)
-- Name: listing_types; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.listing_types AS ENUM (
    'SALE',
    'RENT'
);


--
-- TOC entry 842 (class 1247 OID 16390)
-- Name: property_types; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.property_types AS ENUM (
    'Flat',
    'Bungalow',
    'Plot',
    'Office',
    'Shop',
    'Agricultural Land',
    'Industrial Land'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 217 (class 1259 OID 16443)
-- Name: demand_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.demand_requests (
    id character varying NOT NULL,
    customer_id character varying NOT NULL,
    title character varying,
    description character varying,
    locality character varying,
    property_type public.property_types,
    listing_type public.listing_types,
    furnishing_status public.furnishing_statuses,
    price_min double precision,
    price_max double precision,
    deposit_max double precision,
    bhk_min integer,
    bhk_max integer,
    area_sqft_min integer,
    area_sqft_max integer,
    listed_date character varying,
    lift_available boolean,
    amenities character varying[],
    overlooking character varying[],
    additional_rooms character varying[],
    facing_direction character varying,
    customer_name character varying,
    customer_email character varying,
    customer_phone character varying,
    customer_address character varying,
    customer_referred_by character varying,
    customer_additional_info character varying
);


--
-- TOC entry 215 (class 1259 OID 16419)
-- Name: supply_properties; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supply_properties (
    id character varying NOT NULL,
    customer_id character varying NOT NULL,
    title character varying,
    description character varying,
    locality character varying,
    price double precision,
    deposit double precision,
    bhk integer,
    bathrooms integer,
    area_sqft integer,
    age_of_building integer,
    floor_number integer,
    total_floors integer,
    property_type public.property_types,
    listing_type public.listing_types,
    furnishing_status public.furnishing_statuses,
    facing_direction character varying,
    listed_date character varying,
    lift_available boolean,
    amenities character varying[],
    overlooking character varying[],
    additional_rooms character varying[],
    customer_name character varying,
    customer_email character varying,
    customer_phone character varying,
    customer_address character varying,
    customer_referred_by character varying,
    customer_additional_info character varying
);


--
-- TOC entry 216 (class 1259 OID 16435)
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id character varying NOT NULL,
    email character varying NOT NULL,
    name character varying NOT NULL,
    phone character varying,
    hashed_password character varying NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    is_active boolean
);


--
-- TOC entry 3416 (class 0 OID 16443)
-- Dependencies: 217
-- Data for Name: demand_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.demand_requests (id, customer_id, title, description, locality, property_type, listing_type, furnishing_status, price_min, price_max, deposit_max, bhk_min, bhk_max, area_sqft_min, area_sqft_max, listed_date, lift_available, amenities, overlooking, additional_rooms, facing_direction, customer_name, customer_email, customer_phone, customer_address, customer_referred_by, customer_additional_info) FROM stdin;
\.


--
-- TOC entry 3414 (class 0 OID 16419)
-- Dependencies: 215
-- Data for Name: supply_properties; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supply_properties (id, customer_id, title, description, locality, price, deposit, bhk, bathrooms, area_sqft, age_of_building, floor_number, total_floors, property_type, listing_type, furnishing_status, facing_direction, listed_date, lift_available, amenities, overlooking, additional_rooms, customer_name, customer_email, customer_phone, customer_address, customer_referred_by, customer_additional_info) FROM stdin;
18978d07-4f1f-46e3-ab9f-7f8834c5dbac	8918a540-5f8c-4efc-b18e-31d6d5f80fb3	wqith one node updated 2	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	{}	{}	{}	\N	\N	\N	\N	\N	\N
\.


--
-- TOC entry 3415 (class 0 OID 16435)
-- Dependencies: 216
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, name, phone, hashed_password, created_at, updated_at, is_active) FROM stdin;
8918a540-5f8c-4efc-b18e-31d6d5f80fb3	shauryak3477@gmail.com	Shaurya Khetarpal	9158477773	$2b$12$UJ73Ri5nRPTiOn6FGPR2berbqBHJ5Rczb214So6eYRWRiashUn5QG	2025-12-08 06:21:44.944876	2025-12-08 06:21:44.94488	t
\.


--
-- TOC entry 3269 (class 2606 OID 16449)
-- Name: demand_requests demand_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.demand_requests
    ADD CONSTRAINT demand_requests_pkey PRIMARY KEY (id);


--
-- TOC entry 3264 (class 2606 OID 16425)
-- Name: supply_properties supply_properties_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_properties
    ADD CONSTRAINT supply_properties_pkey PRIMARY KEY (id);


--
-- TOC entry 3267 (class 2606 OID 16441)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3270 (class 1259 OID 16450)
-- Name: ix_demand_requests_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_demand_requests_customer_id ON public.demand_requests USING btree (customer_id);


--
-- TOC entry 3262 (class 1259 OID 16426)
-- Name: ix_supply_properties_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_supply_properties_customer_id ON public.supply_properties USING btree (customer_id);


--
-- TOC entry 3265 (class 1259 OID 16442)
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


-- Completed on 2025-12-08 07:18:30 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict d5CrC7zvcgaibmkiFHe6TCk3gly0gb5vHfx5qJOrzTuns9NEcjkBc8jQ7bGtxFr

