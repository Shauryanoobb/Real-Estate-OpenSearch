--
-- PostgreSQL database dump
--

\restrict b7XxbIc8eJcf6UdJSkR446AxFAzoE1abCwU8O6IW4QoQpqM82pbRrEve4Fcdp1S

-- Dumped from database version 16.1
-- Dumped by pg_dump version 16.11 (Homebrew)

-- Started on 2025-12-06 10:51:21 IST

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS realestate_db;
--
-- TOC entry 3427 (class 1262 OID 16557)
-- Name: realestate_db; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE realestate_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


\unrestrict b7XxbIc8eJcf6UdJSkR446AxFAzoE1abCwU8O6IW4QoQpqM82pbRrEve4Fcdp1S
\connect realestate_db
\restrict b7XxbIc8eJcf6UdJSkR446AxFAzoE1abCwU8O6IW4QoQpqM82pbRrEve4Fcdp1S

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 842 (class 1247 OID 16559)
-- Name: furnishing_statuses; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.furnishing_statuses AS ENUM (
    'FURNISHED',
    'UNFURNISHED',
    'SEMI_FURNISHED'
);


--
-- TOC entry 845 (class 1247 OID 16566)
-- Name: listing_types; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.listing_types AS ENUM (
    'SALE',
    'RENT'
);


--
-- TOC entry 848 (class 1247 OID 16572)
-- Name: property_types; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.property_types AS ENUM (
    'Flat',
    'Bungalow',
    'Plot',
    'Office',
    'Shop',
    'Agricultural Land',
    'Industrial Land'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 217 (class 1259 OID 16621)
-- Name: demand_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.demand_requests (
    id character varying NOT NULL,
    customer_id character varying NOT NULL,
    title character varying,
    description character varying,
    locality character varying,
    property_type public.property_types,
    listing_type public.listing_types,
    furnishing_status public.furnishing_statuses,
    price_min double precision,
    price_max double precision,
    deposit_max double precision,
    bhk_min integer,
    bhk_max integer,
    area_sqft_min integer,
    area_sqft_max integer,
    listed_date character varying,
    lift_available boolean,
    amenities character varying[],
    overlooking character varying[],
    additional_rooms character varying[],
    facing_direction character varying,
    customer_name character varying,
    customer_email character varying,
    customer_phone character varying,
    customer_address character varying,
    customer_referred_by character varying,
    customer_additional_info character varying
);


--
-- TOC entry 216 (class 1259 OID 16613)
-- Name: supply_properties; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supply_properties (
    id character varying NOT NULL,
    customer_id character varying NOT NULL,
    title character varying,
    description character varying,
    locality character varying,
    price double precision,
    deposit double precision,
    bhk integer,
    bathrooms integer,
    area_sqft integer,
    age_of_building integer,
    floor_number integer,
    total_floors integer,
    property_type public.property_types,
    listing_type public.listing_types,
    furnishing_status public.furnishing_statuses,
    facing_direction character varying,
    listed_date character varying,
    lift_available boolean,
    amenities character varying[],
    overlooking character varying[],
    additional_rooms character varying[],
    customer_name character varying,
    customer_email character varying,
    customer_phone character varying,
    customer_address character varying,
    customer_referred_by character varying,
    customer_additional_info character varying
);


--
-- TOC entry 215 (class 1259 OID 16601)
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id character varying NOT NULL,
    email character varying NOT NULL,
    name character varying NOT NULL,
    phone character varying,
    hashed_password character varying NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    is_active boolean DEFAULT true,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 3421 (class 0 OID 16621)
-- Dependencies: 217
-- Data for Name: demand_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.demand_requests (id, customer_id, title, description, locality, property_type, listing_type, furnishing_status, price_min, price_max, deposit_max, bhk_min, bhk_max, area_sqft_min, area_sqft_max, listed_date, lift_available, amenities, overlooking, additional_rooms, facing_direction, customer_name, customer_email, customer_phone, customer_address, customer_referred_by, customer_additional_info) FROM stdin;
\.


--
-- TOC entry 3420 (class 0 OID 16613)
-- Dependencies: 216
-- Data for Name: supply_properties; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supply_properties (id, customer_id, title, description, locality, price, deposit, bhk, bathrooms, area_sqft, age_of_building, floor_number, total_floors, property_type, listing_type, furnishing_status, facing_direction, listed_date, lift_available, amenities, overlooking, additional_rooms, customer_name, customer_email, customer_phone, customer_address, customer_referred_by, customer_additional_info) FROM stdin;
874b7d49-917f-4f37-a41c-2326aa84fe1f	1a31ddb8-2194-47e8-b35d-6c62e410f680	atharva	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	{}	{}	{}	\N	\N	\N	\N	\N	\N
4070a7b2-d32f-49b9-af9f-28793762869a	a6ad5851-0429-4776-b335-96b4940a8ee4	this is iit 2	iit	simrol	1234000	\N	10	2	10000	12	2	2	Flat	SALE	FURNISHED	North	2025-12-05	t	{}	{"Main Road"}	{"Study Room"}	me	\N	\N	\N	\N	\N
8c525157-fb9b-48ec-9e7e-2475f650d50c	9525e9db-530f-40e7-a65b-e135b2ecf85b	Through phone shaurya	Dont kno	Shankar nagar	1000000	\N	3	2	2000	2	2	2	Flat	SALE	FURNISHED	North	2025-12-05	t	{Gym}	{"Main Road",Pool}	{"Store Room","Servant Room"}	Shaurya Khetarpal	\N	\N	\N	\N	\N
4206ba03-cded-48fb-81d3-d054c679f915	a6ad5851-0429-4776-b335-96b4940a8ee4	Apj hostel 2	\N	Simrol	\N	\N	3	\N	\N	\N	\N	\N	Flat	SALE	\N	\N	\N	\N	{}	{}	{}	\N	\N	\N	\N	\N	\N
\.


--
-- TOC entry 3419 (class 0 OID 16601)
-- Dependencies: 215
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, name, phone, hashed_password, created_at, is_active, updated_at) FROM stdin;
9525e9db-530f-40e7-a65b-e135b2ecf85b	shauryak3477@gmail.com	Shaurya Khetarpal	9158477773	$2b$12$jf6mufs9ANGExxEUHOwdRubAoQupoTDLiD8y3Fmm9vaxcMigA8FgO	2025-12-05 17:38:24.254271	t	2025-12-05 17:38:24.254275
a6ad5851-0429-4776-b335-96b4940a8ee4	cse220001074@iiti.ac.in	iit indore	9158477773	$2b$12$WiHfkI.H8ThyriQdOFwrteY5IxbmU0cmPlBzqI4.Nv1jIDqxr5GZe	2025-12-05 17:41:43.261605	t	2025-12-05 17:41:43.26161
1a31ddb8-2194-47e8-b35d-6c62e410f680	ex@gmail.com	Shaurya	9158477773	$2b$12$o3oDFMVFwdcxpPtSPB4W6uUcUqGGu0EruAcIrHpRsaLSl.nr9w9XC	2025-12-05 17:53:55.281267	t	2025-12-05 17:53:55.28127
\.


--
-- TOC entry 3274 (class 2606 OID 16627)
-- Name: demand_requests demand_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.demand_requests
    ADD CONSTRAINT demand_requests_pkey PRIMARY KEY (id);


--
-- TOC entry 3272 (class 2606 OID 16619)
-- Name: supply_properties supply_properties_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_properties
    ADD CONSTRAINT supply_properties_pkey PRIMARY KEY (id);


--
-- TOC entry 3267 (class 2606 OID 16611)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 3269 (class 2606 OID 16609)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3265 (class 1259 OID 16612)
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- TOC entry 3275 (class 1259 OID 16628)
-- Name: ix_demand_requests_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_demand_requests_customer_id ON public.demand_requests USING btree (customer_id);


--
-- TOC entry 3270 (class 1259 OID 16620)
-- Name: ix_supply_properties_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_supply_properties_customer_id ON public.supply_properties USING btree (customer_id);


-- Completed on 2025-12-06 10:51:21 IST

--
-- PostgreSQL database dump complete
--

\unrestrict b7XxbIc8eJcf6UdJSkR446AxFAzoE1abCwU8O6IW4QoQpqM82pbRrEve4Fcdp1S

